/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cst8218.aziz0034.bouncer.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ramses Aziz
 */
@Entity
@Table(name = "BOUNCER")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Bouncer.findAll", query = "SELECT b FROM Bouncer b"),
    @NamedQuery(name = "Bouncer.findById", query = "SELECT b FROM Bouncer b WHERE b.id = :id"),
    @NamedQuery(name = "Bouncer.findByX", query = "SELECT b FROM Bouncer b WHERE b.x = :x"),
    @NamedQuery(name = "Bouncer.findByY", query = "SELECT b FROM Bouncer b WHERE b.y = :y"),
    @NamedQuery(name = "Bouncer.findByXSpeed", query = "SELECT b FROM Bouncer b WHERE b.ySpeed = :xSpeed"),
    @NamedQuery(name = "Bouncer.findByYSpeed", query = "SELECT b FROM Bouncer b WHERE b.ySpeed = :ySpeed")})
public class Bouncer implements Serializable {
    
    private static final int FRAME_HEIGHT = 500;
    private static final int FRAME_WIDTH = 500;
    private static final int GRAVITY_ACCEL = 1;
    private static final int DECAY_RATE = 1;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ID")
    private Long id ;
    @Basic(optional = false)
    @NotNull
    @Column(name = "X")
    private int x;
    @Basic(optional = false)
    @NotNull
    //TODO @Max
    @Column(name = "Y")
    private int y;
    @Basic(optional = false)
    @NotNull
    @Column(name = "XSPEED")
    private int xSpeed;
    @Basic(optional = false)
    @NotNull
    //@Max
    @Column(name = "YSPEED")
    private int ySpeed;

    public Bouncer() {
    }

    public Bouncer(Long id) {
        this.id = id;
    }

    public Bouncer(Long id, int x, int y, int xSpeed, int ySpeed) {
        this.id = id;
        this.x = x;
        this.y = y;
        this.xSpeed = xSpeed;
        this.ySpeed = ySpeed;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getXSpeed() {
        return xSpeed;
    }

    public void setXSpeed(int ySpeed) {
        this.xSpeed = ySpeed;
    }

    public int getYSpeed() {
        return ySpeed;
    }

    public void setYSpeed(int ySpeed) {
        this.ySpeed = ySpeed;
    }    
    
    /**
     * Advances the Bouncer's y position by some amount each time
     * that the method is invoked. The direction may also be changed
     * if the entity "collides" with the screen's boundary i.e. 
     * escapes the acceptable range of 0 to FRAME_HEIGHT.
     */
    public void advanceOneFrame() {        
        if (y < FRAME_HEIGHT) // If we haven't reached the screen boundary...
            ySpeed += GRAVITY_ACCEL;
        
        y += ySpeed; // Increase y by a factor of ySpeed pixels per frame
        
        if (y <= 0 || y >= FRAME_HEIGHT) {
            // Clamp to edge
            y = (y <= 0) ? 0 : FRAME_HEIGHT;
            
            // Invert direction and decrease the rate of change
            if (ySpeed != 0) {
                ySpeed *= -1;
                ySpeed += (ySpeed < 0) ? DECAY_RATE : -DECAY_RATE;
            }
        }
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Bouncer)) {
            return false;
        }
        Bouncer other = (Bouncer) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cst8218.aziz0034.bouncer.entity.Bouncer[ id=" + id + " ]";
    }
    
}
