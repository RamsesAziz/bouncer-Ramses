package cst8218.aziz0034.bouncer.resources;

import cst8218.aziz0034.bouncer.AbstractFacade;
import cst8218.aziz0034.bouncer.entity.Bouncer;
import java.util.Collections;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

@Stateless
@Path("cst8218.aziz0034.bouncer.entity.bouncer")
public class BouncerFacadeREST extends AbstractFacade<Bouncer> {

    @PersistenceContext(unitName = "my_persistence_unit")
    private EntityManager em;

    public BouncerFacadeREST() {
        super(Bouncer.class);
    }
    
    /**
     * Part B - Endpoint used for retrieving the count of rows in the DB.
     * 
     * @return A Response object with the count value and an appropriate status
     */
    @GET
    @Path("count")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response countREST() {
        long count = super.count(); // Get the count value

        // Build the response entity with the count value and status 200 (OK)
        return Response.ok(count).build();
    }

    /**
     * Part C - Endpoint used to create a new bouncer.
     * Acts upon the root resource and accepts an entity in the request.
     * Missing fields are initialized to sensible defaults.
     * 
     * @param entity The entity received from the JSON/XML request
     * @param uriInfo A UriInfo instance used to retrieve the location of the 
     *                newly created bouncer entity
     * @return Response with status 201 (created) on success, or an appropriate error status
     */
    @POST
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response createBouncer(Bouncer entity, @Context UriInfo uriInfo) {
        if (entity.getId() != null && entity.getId().equals(entity.getId())) {
            return Response
                    .status(Response.Status.BAD_REQUEST) // Status 400 - Bad Request
                    .build(); 
        } else { // Set sensible defaults
            if (entity.getX() == 0) 
                entity.setX(250);
            if (entity.getY() == 0) 
                entity.setY(0);
            if (entity.getXSpeed() == 0)
                entity.setXSpeed(0);
            if (entity.getYSpeed() == 0)
                entity.setYSpeed(5);
        }
        // Create the new entity
        super.create(entity);
        
        UriBuilder uriBuilder = uriInfo.getAbsolutePathBuilder();
        uriBuilder.path(Long.toString(entity.getId()));
        
        return Response
                .status(Response.Status.CREATED) // Status 201 - Created
                .location(uriBuilder.build())
                .entity(entity)
                .build();
    }
    
    /**
     * Part D - Endpoint used for updating an existing entity in the DB.
     * The ID specified in the JSON/XML request must match the ID in the path.
     * Additionally, the DB must contain an entity with a matching ID.
     * Existing values are <i>not</i> overwritten.
     * 
     * @param id The ID received from the request path
     * @param entity The entity received from the JSON/XML request
     * @return Status 200 (ok) on success, otherwise an appropriate error status
     */
    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response update(@PathParam("id") Long id, Bouncer entity) {
        if (!id.equals(entity.getId())) {
            return Response
                    .status(Response.Status.BAD_REQUEST) // Status 400 - Bad Request
                    .build();
        }
        
        // Search DB for entity with matching id
        Bouncer existing = super.find(entity.getId());
        if (existing == null) {
            return Response
                    .status(Response.Status.NOT_FOUND) // Status 404 - Not Found
                    .build();
        }
        
        // Do not override existing values if they were not set by the user
        if (entity.getX() == 0) 
            entity.setX(existing.getX());
        if (entity.getY() == 0)
            entity.setY(existing.getY());
        if (entity.getXSpeed() == 0)
            entity.setXSpeed(existing.getXSpeed());
        if (entity.getYSpeed() == 0)
            entity.setYSpeed(existing.getYSpeed());
        
        // Update the entity
        super.edit(entity);
        
        return Response
                .status(Response.Status.OK) // Status 200 - OK
                .build();
    }

    /**
     * Part E - Endpoint used for updating an existing entity in the DB.
     * The ID specified in the JSON/XML request must match the ID in the path.
     * Additionally, the DB must contain an entity with a matching ID.
     * Existing values <i>are</i> overwritten.
     * 
     * @param id The ID received from the request path
     * @param entity The entity received from the JSON/XML request
     * @return Status 200 (ok) on success, otherwise an appropriate error status
     */
    @PUT
    @Path("{id}/overwrite")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response edit(@PathParam("id") Long id, Bouncer entity) {
        if (!id.equals(entity.getId())) {
            return Response
                    .status(Response.Status.BAD_REQUEST) // Status 400 - Bad Request
                    .build();
        }
        
        Bouncer existing = super.find(entity.getId());
        if (existing == null) {
            return Response
                    .status(Response.Status.NOT_FOUND) // Status 404 - Not Found
                    .build();
        } else if (!existing.getId().equals(id)) {
            return Response
                    .status(Response.Status.INTERNAL_SERVER_ERROR) // Status 500 - Internal Server Error
                    .build();
        }
        
        // Update the entity, regardless of values
        super.edit(entity);
        
        return Response
                .status(Response.Status.OK) // Status 200 - OK
                .build();
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
}
